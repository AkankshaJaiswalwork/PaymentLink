require('dotenv').config();
const app = require('./app');
const { startStaleLinkSweeper } = require('./jobs');

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Phase 4 Server listening on port ${PORT}`);
  startStaleLinkSweeper();
});
