# Architecture

PayLink uses a standard three-tier architecture suitable for a Node.js API:
- **Web Framework:** Express.js for routing, middleware, and request handling.
- **Database:** PostgreSQL accessed via `pg` (node-postgres) driver. We chose raw SQL over an ORM to demonstrate fundamental backend skills and maintain direct control over queries for idempotency and analytics.
- **Payment Gateway:** Stripe in test mode via the `stripe` Node SDK. 
- **Authentication:** Stateless JWTs, removing the need for server-side session storage for the MVP.

## Components
- `app.js`: Core Express application containing routes and logic.
- `auth.js`: JWT verification middleware.
- `db.js`: PostgreSQL connection pool wrapper.
- `jobs.js`: Simple `setInterval` based background jobs (e.g., expiring links) negating the need for a complex Redis/BullMQ setup for this scale.
- `stripe.js`: Singleton Stripe instance configuration.
