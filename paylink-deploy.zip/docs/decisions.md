# Architecture Decision Records

## 1. Short Code Generation
**Context:** We need a short code to identify payment links.
**Decision:** Use `nanoid(7)` rather than auto-increment IDs or base62 encoding.
**Consequences:** Prevents competitors from easily enumerating all links and guessing business metrics. 7 random characters provide sufficient entropy for our scale.

## 2. Stateless JWT Authentication
**Context:** Merchants need to securely authenticate to create links.
**Decision:** Use JWTs issued upon login, stored on the client side.
**Consequences:** Simplifies backend architecture by avoiding session tables in Postgres or adding Redis for session management. Trade-off: Revoking active tokens before expiry is difficult, but acceptable for this MVP.

## 3. Webhook Idempotency
**Context:** Stripe webhooks can be delivered multiple times.
**Decision:** In the webhook handler, query the database to check the link's `status` before executing an `UPDATE`.
**Consequences:** If `status` is already `paid` or `expired`, the webhook is safely ignored. We avoid double-processing events without needing a separate `webhooks_processed` table.

## 4. Background Expiry Job
**Context:** Links need to expire if not paid before their `expires_at` timestamp.
**Decision:** Use a native Node.js `setInterval` loop that executes a `UPDATE ... WHERE expires_at < NOW()` query every 5 minutes.
**Consequences:** Highly simple and effective for a single-server deployment. If the app is scaled horizontally to multiple instances, this approach might cause redundant DB queries, and we should transition to a distributed cron (like Redis + Bull).
