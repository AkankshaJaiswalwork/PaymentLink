const request = require('supertest');
const app = require('../app');
const db = require('../db');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../auth');

jest.mock('../db', () => ({
  query: jest.fn(),
  pool: { end: jest.fn() }
}));

const generateToken = (id = 1) => jwt.sign({ id, email: 'test@test.com' }, JWT_SECRET, { expiresIn: '1h' });

describe('Analytics & Hardening Endpoints', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('GET /links returns list of links', async () => {
    db.query.mockResolvedValueOnce({ rows: [{ code: 'code1', clicks: 5 }] });
    const res = await request(app)
      .get('/links')
      .set('Authorization', `Bearer ${generateToken()}`);

    expect(res.status).toBe(200);
    expect(res.body.links[0]).toHaveProperty('clicks', 5);
  });

  test('GET /links/:code/stats returns time_to_pay', async () => {
    const created = new Date('2024-01-01T10:00:00Z');
    const paid = new Date('2024-01-01T10:05:00Z');
    
    db.query.mockResolvedValueOnce({ 
      rows: [{ code: 'code1', clicks: 5, status: 'paid', created_at: created, paid_at: paid }] 
    });
    
    const res = await request(app)
      .get('/links/code1/stats')
      .set('Authorization', `Bearer ${generateToken()}`);

    expect(res.status).toBe(200);
    expect(res.body.time_to_pay_seconds).toBe(300);
  });

  test('POST /links triggers rate limit if > 50 links created in hour', async () => {
    db.query.mockResolvedValueOnce({ rows: [{ count: '50' }] });
    
    const res = await request(app)
      .post('/links')
      .set('Authorization', `Bearer ${generateToken()}`)
      .send({ amount: 1000, currency: 'usd', description: 'Spam' });

    expect(res.status).toBe(429);
    expect(res.body.error).toBe('Max links per hour exceeded.');
  });
});
