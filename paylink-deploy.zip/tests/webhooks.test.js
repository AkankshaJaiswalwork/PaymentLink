const request = require('supertest');
const app = require('../app');
const db = require('../db');
const stripe = require('../stripe');

jest.mock('../db', () => ({
  query: jest.fn(),
  pool: { end: jest.fn() }
}));

jest.mock('../stripe', () => ({
  webhooks: { constructEvent: jest.fn() }
}));

describe('Webhook Endpoints', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('POST /webhook handles completed and sets paid_at', async () => {
    const mockEvent = {
      type: 'checkout.session.completed',
      data: { object: { metadata: { code: 'code123' } } }
    };
    stripe.webhooks.constructEvent.mockReturnValueOnce(mockEvent);

    db.query
      .mockResolvedValueOnce({ rows: [{ status: 'pending' }] }) // SELECT
      .mockResolvedValueOnce({}); // UPDATE paid

    const res = await request(app)
      .post('/webhook')
      .send(mockEvent)
      .set('Stripe-Signature', 'valid_sig');

    expect(res.status).toBe(200);
    expect(db.query).toHaveBeenNthCalledWith(2, 'UPDATE links SET status = $1, paid_at = CURRENT_TIMESTAMP WHERE code = $2', ['paid', 'code123']);
  });
});
