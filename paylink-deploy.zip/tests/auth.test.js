const request = require('supertest');
const app = require('../app');
const db = require('../db');
const bcrypt = require('bcryptjs');

jest.mock('../db', () => ({
  query: jest.fn(),
  pool: { end: jest.fn() }
}));

describe('Auth Endpoints', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('POST /signup creates a new user', async () => {
    db.query.mockResolvedValueOnce({ rows: [{ id: 1, email: 'test@example.com' }] });
    const res = await request(app).post('/signup').send({ email: 'test@example.com', password: 'password123' });
    expect(res.status).toBe(201);
  });

  test('POST /login returns JWT on success', async () => {
    const hashedPassword = await bcrypt.hash('password123', 10);
    db.query.mockResolvedValueOnce({ rows: [{ id: 1, email: 'test@example.com', password_hash: hashedPassword }] });
    const res = await request(app).post('/login').send({ email: 'test@example.com', password: 'password123' });
    expect(res.status).toBe(200);
  });
});
