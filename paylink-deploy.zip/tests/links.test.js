const request = require('supertest');
const app = require('../app');
const db = require('../db');
const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../auth');
const stripe = require('../stripe');

jest.mock('../db', () => ({
  query: jest.fn(),
  pool: { end: jest.fn() }
}));

jest.mock('../stripe', () => ({
  checkout: { sessions: { create: jest.fn() } }
}));

const generateToken = (id = 1) => jwt.sign({ id, email: 'test@test.com' }, JWT_SECRET, { expiresIn: '1h' });

describe('Links Endpoints with Stripe', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  test('POST /links creates link', async () => {
    db.query.mockResolvedValueOnce({ rows: [{ count: '0' }] }); // rate limit check
    db.query.mockResolvedValueOnce({ rows: [{ code: 'code123' }] }); // insert
    const res = await request(app)
      .post('/links')
      .set('Authorization', `Bearer ${generateToken()}`)
      .send({ amount: 1000, currency: 'usd', description: 'Test' });

    expect(res.status).toBe(201);
  });

  test('GET /:code redirects to Stripe and increments clicks', async () => {
    db.query.mockResolvedValueOnce({}); // Increment clicks
    db.query.mockResolvedValueOnce({ 
      rows: [{ id: 1, code: 'code123', amount: 1000, currency: 'usd', status: 'pending', expires_at: null }] 
    });
    db.query.mockResolvedValueOnce({}); // UPDATE status to used

    stripe.checkout.sessions.create.mockResolvedValueOnce({ url: 'https://checkout.stripe.mock/session_123' });

    const res = await request(app).get('/code123');
    
    expect(res.status).toBe(303);
    expect(res.header.location).toBe('https://checkout.stripe.mock/session_123');
  });
});
